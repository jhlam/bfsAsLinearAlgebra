#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int display_array(int target[], int N);
int increas_array(int target[], int N, int value);
int init_matrix(int A[][7], int N);
int print_matrix(int A[][7], int N);
int print_vector(int v[], int N);
int increas_matrix(int A[][7], int N, int value);
int matrix_vector_multiplication(int A[][7], int V[], int N, int Y[], int p_g );
int bfs_simulation(int A[][7], int result[], int root[], int N, int p_g);
int distGen(int dist[], int level, int x[], int y[], int Nz);
