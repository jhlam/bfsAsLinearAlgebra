#include "bfs.h"

int display_array(int target[], int N){
    for(int i=0; i<N; i++){
        printf("%i ", target[i]);
    }
    printf("\n");
    return 0;
}

int print_vector(int v[], int N){
    for (int i=0; i<N; i++){
        printf("%i ", v[i]);
    }
   // printf("\n");
}

int increas_array(int target[], int N, int value){
    for(int i=0; i<N; i++){
        target[i]=target[i]+value;
    }
    return 0;
}

int init_matrix(int A[][7], int N){
    for(int i=0; i<N; i++){
        for(int j=0; j<N; j++){
            A[i][j] = 0;
        }
    }
    return 0;
}

int print_matrix(int A[][7], int N){
    for(int i = 0; i<N; i++){
        for(int j = 0; j<N; j++){
            printf("%i ", A[i][j]);
        }
        printf("\n");
    }
}

int increas_matrix(int A[][7], int N, int value){
    for(int i=0; i<N; i++){
        increas_array(A[i], N, value);
    }
    return 0;
}
int matrix_vector_multiplication(int A[][7], int V[], int N, int Y[], int p_g ){
    int seed = 42; //Just a random number chosen as seed for RNG
    srand((unsigned)seed);

    int coin;
    int result = 0;

    for(int i=0; i<N; i++){
        for(int j=0; j<N; j++){
            coin= (rand()%100)+1;
            //Can make this more sparse, might save a lot of computation steps.
            if(V[j]== 1 && A[i][j]==1){
                    if(i==j){
                        result = (A[i][j] && V[j]) ||result ;
                    }
                    else{
                        result = (A[i][j] && V[j] && (coin<p_g)) ||result ;
                    }
                 //temp = temp && ((coin%100)<p_g);
               // printf("coin: %i \n", coin%100);
            }
        }
        Y[i] = result;

        result =0;
        //printf("\n");
    }
    return 0;
}

//Need fixings, this is just a copy-paste
int distGen(int dist[], int level, int x[], int y[], int N){
	int update = 0;
	for (int i= 0; i<N; i++){
		if(x[i]== 0 && y[i]==1){
			dist[i] = level;
			update=update+1;
		}
	}
	return update==0;
}

int print_result(int x[],int steps, int N, char r){
    printf("%c_%i:[", r, steps);
    for(int i=0; i<N; i++){
        printf("%i ", x[i]);
    }
    printf("]");
}


int bfs_simulation(int A[][7], int result[], int root[], int N, int p_g){
//---------declare variable that will be used.-------------
    int dist[7]={};
	int level = 1;
	int converged = 0;
	int x[7]={};
	int y[7]={};
    int steps=0;
//-----------initiate some of the vectors---------------
	 for(int i = 0; i<N; i++){
            dist[i]= -1;
            x[i]=root[i];
	}
//---------------Main computation-------------------
/**
    printf("Matrix A: \n");
    print_matrix(A,N);
    printf("Vector x: \n");
    print_vector(root,N);
    printf("\n");
**/
	while(!converged){

        //printf("%i steps", steps);

		matrix_vector_multiplication(A,x,N, y, p_g);
		//----------Print matrix for reference
/**
        print_result(x,steps,N,'X');
        printf(" => ");
        print_result(y,steps++,N,'Y');
        printf("\n");
**/
        converged = distGen(dist, level, x,y, N);


		for(int i=0; i<N ; i++){
            x[i]=y[i];
		}


		level += 1;
	}

	for(int i=0; i<N ; i++){
            result[i]=y[i];
        }

    return dist;

}


